##'--------------------------------
##' spore_CFU
##' 2023-03-27
##'
##'---------------------------------

spore_cfu <- read_xlsx("data/CFU_counts.xlsx", sheet = "Swab_Pastuerized_CFU") |>
  mutate(spore_cfu, Species = c("Salamandra salamandra", "Salamandra salamandra", "Salamandra salamandra", "Salamandra salamandra", "Salamandra salamandra", "Ambystoma maculatum",
"Ambystoma maculatum",
"Ambystoma maculatum",
"Ambystoma maculatum",
"Ambystoma maculatum", 
"Bombina orientalis" ,
"Bombina orientalis" ,
"Bombina orientalis",
"Bombina orientalis",
"Bombina orientalis",
"Notophthalmus viridescens",
"Notophthalmus viridescens",
"Notophthalmus viridescens",
"Notophthalmus viridescens",
"Notophthalmus viridescens",
"Litoria caerulea",
"Litoria caerulea",
"Litoria caerulea",
"Litoria caerulea",
"Litoria caerulea",
"Eurycea wilderae",
"Eurycea wilderae",
"Eurycea wilderae",
"Eurycea wilderae",
"Eurycea wilderae"))

ggplot(spore_cfu, aes(Species, CFU_ml, fill=Species))+
  geom_boxplot()+
  theme_bw() +
  ylab("spore-forming bacteria per mL (log10)")+
  xlab("Species") +
  scale_y_log10()+
  coord_flip()+
  theme(legend.position="none") +
  theme(plot.title = element_text(hjust = 0.5)) +
  theme(text = element_text(family = 'serif', face = 'bold', size = 18))

spore_cfu_lm <- lm(CFU_ml ~ Species, data = spore_cfu)
Anova(spore_cfu_lm)

means <- emmeans(spore_cfu_lm, "Species")
pairs(means)
  

