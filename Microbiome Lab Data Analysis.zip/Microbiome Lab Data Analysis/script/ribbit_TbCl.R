Ribbit_tbcl <- read_xlsx("data/RIBBiTR_TbCl_data.xlsx")

Ribbit_tbcl[Ribbit_tbcl < 0] <- 0

# TbCl assay by location and by species 
ggplot(Ribbit_tbcl, aes(Species, Num_spores, fill = Location)) +
  geom_boxplot() +
  theme_bw() +
  coord_flip()+
  theme(legend.position="none") +
  theme(axis.title.x = element_blank()) +
  theme(axis.title.y = element_blank()) +
  theme(text = element_text(family = 'serif', face = 'bold', size = 20))

Ribbit_tbcl_lm <- lm(Num_spores ~ Species, data = Ribbit_tbcl)
tukey <- Anova(Ribbit_tbcl_lm)

means <- emmeans(Ribbit_tbcl_lm, "Species")
pairs(means)
