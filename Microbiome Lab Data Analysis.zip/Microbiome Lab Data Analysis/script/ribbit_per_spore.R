Ribbit_per_spore <- read_xlsx("data/RIBBiTR_TbCl_data.xlsx")

ggplot(Ribbit_per_spore, aes(Species, Per_viable_spore, fill = Location)) +
  geom_boxplot() +
  coord_flip() +
  theme_bw()+
  theme(
    legend.position = c(.95, .95),
    legend.justification = c("right", "top"),
    legend.box.just = "right",
    legend.margin = margin(6, 6, 6, 6)
  ) +
  ylab("Percente Viable Spores") +
  theme(text = element_text(family = 'serif', face = 'bold', size = 18)) +
  
  
