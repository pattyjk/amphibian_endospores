# loads in data and adds species
spore_tbCL <- read_xlsx("data/TbCl_swabs_viable_spores.xlsx") |>
  mutate(spore_tbCL, species = c("Salamandra salamandra","Salamandra salamandra","Salamandra salamandra", "Ambystoma maculatum", "Ambystoma maculatum", "Ambystoma maculatum",
                                 "Bombina orientalis", "Bombina orientalis", "Bombina orientalis", "Litoria caerulea", "Litoria caerulea", "Litoria caerulea", 
                                 "Salamandra salamandra", "Salamandra salamandra", "Salamandra salamandra", "Bombina orientalis", "Bombina orientalis", "Bombina orientalis",
                                 "Notophthalmus viridescens", "Notophthalmus viridescens", "Notophthalmus viridescens", "Eurycea wilderae", "Eurycea wilderae", "Eurycea wilderae",
                                 "Salamandra salamandra", "Salamandra salamandra", "Salamandra salamandra", "Bombina orientalis", "Bombina orientalis", "Bombina orientalis",
                                 "Notophthalmus viridescens", "Notophthalmus viridescens", "Notophthalmus viridescens", "Eurycea wilderae", "Eurycea wilderae", "Eurycea wilderae",
                                 "Salamandra salamandra", "Salamandra salamandra", "Salamandra salamandra", "Bombina orientalis", "Bombina orientalis", "Bombina orientalis", 
                                 "Litoria caerulea", "Litoria caerulea", "Litoria caerulea", "Eurycea wilderae", "Eurycea wilderae", "Eurycea wilderae", "Salamandra salamandra", 
                                 "Salamandra salamandra", "Salamandra salamandra", "Bombina orientalis", "Bombina orientalis", "Bombina orientalis", "Notophthalmus viridescens",
                                 "Notophthalmus viridescens","Notophthalmus viridescens", "Eurycea wilderae", "Eurycea wilderae", "Eurycea wilderae", "Ambystoma maculatum", 
                                 "Ambystoma maculatum", "Ambystoma maculatum", "Bombina orientalis", "Bombina orientalis", "Bombina orientalis", "Litoria caerulea", "Litoria caerulea",
                                 "Litoria caerulea", "Eurycea wilderae", "Eurycea wilderae", "Eurycea wilderae", "Ambystoma maculatum", "Ambystoma maculatum", "Ambystoma maculatum",
                                 "Bombina orientalis", "Bombina orientalis", "Bombina orientalis", "Litoria caerulea", "Litoria caerulea", "Litoria caerulea", 
                                 NA, NA, NA, "Ambystoma maculatum", "Ambystoma maculatum", "Ambystoma maculatum", "Notophthalmus viridescens", "Notophthalmus viridescens", "Notophthalmus viridescens",
                                 "Litoria caerulea", "Litoria caerulea", "Litoria caerulea", NA, NA, NA)) |>
  select(c("species", "Num_spores", "SampleID"))
  
  # sets all values below zero as equal to zero 
spore_tbCL[spore_tbCL < 0] <- 0

spore_tbCL <- spore_tbCL |>
  filter(!is.na(species))

# plot of spore count from TbCl versus species
ggplot(spore_tbCL, aes(species, Num_spores, fill = species))+
  geom_boxplot()+
  theme_bw() +
  ylab("spore-forming bacteria (log10)")+
  xlab("Species") +
  scale_y_log10()+
  theme(legend.position="none") +
  coord_flip()+
  theme(plot.title = element_text(hjust = 0.5)) +
  theme(text = element_text(family = 'serif', face = 'bold', size = 18))

View(spore_tbcl)
str(spore_tbCL)

spore_tbcl_lm <- lm(Num_spores ~ species, data = spore_tbCL)
Anova(spore_tbcl_lm)

means <- emmeans(spore_tbcl_lm, "species")
pairs(means)
