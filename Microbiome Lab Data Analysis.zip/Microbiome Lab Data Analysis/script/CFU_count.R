##'--------------------------------
##' Lab Data Analysis
##' CFUs
##' 2023-03-27
##'
##'---------------------------------

cfu <- read.delim("data/cfu.txt") |>
  filter(Method == "Swab")

ggplot(cfu, aes(Species, cfu$CFU.ml, fill = Species))+
  geom_boxplot()+
  theme_bw()+
  scale_y_log10()+
  xlab("")+
  ylab("CFU/mL") 
