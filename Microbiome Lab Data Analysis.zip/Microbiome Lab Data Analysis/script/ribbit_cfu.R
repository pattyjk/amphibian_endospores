Ribbit_cfu <- read_xlsx("data/RIBBiTR_CFUs.xlsx")

# spore cfu counts by species and location 
ggplot(Ribbit_cfu, aes(Species, CFU_past, fill = Location)) +
  geom_boxplot() +
  theme_bw() +
  ylab("Spores per mL")+
  xlab("Species") +
  coord_flip() +
  theme(text = element_text(family = 'serif', face = 'bold', size = 20)) +
  theme(
    legend.position = c(.95, .95),
    legend.justification = c("right", "top"),
    legend.box.just = "right",
    legend.margin = margin(6, 6, 6, 6)
  )
  
Ribbit_cfu_lm <- lm(CFU_past ~ Species, data = Ribbit_cfu)
tukey <- Anova(Ribbit_cfu_lm)

means <- emmeans(Ribbit_cfu_lm, "Species")
pairs(means)
