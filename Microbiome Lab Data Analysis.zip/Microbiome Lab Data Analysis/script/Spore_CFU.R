##'--------------------------------
##' Lab Data Analysis
##' % Spores CFU
##' 2023-03-27
##'
##'---------------------------------

spores<-read.delim("data/spore_cfu.txt", sep= '\t', header=T)
spores <- spores |>
  filter(Method == "Swab")

ggplot(spores, aes(Species, Per_spore, fill=Species))+
  geom_boxplot()+
  theme_bw() +
  ylab("Percent spore-forming bacteria")+
  xlab("") +
  theme(legend.position="none") +
  ggtitle("Percent Spore Forming Bacteria per Species") +
  theme(plot.title = element_text(hjust = 0.5)) +
  theme(text = element_text(family = 'serif', face = 'bold', size = 12))
  
