temp_spore <- read_xlsx("data/RIBBiTR_TbCl_data.xlsx", sheet = 2) |> 
  filter(Species != "Pseudacris crucifer")

temp_spore[temp_spore < 0] <- 0

ggplot(temp_spore, aes(Microhab_temp, Num_spores, color = Species)) +
  geom_point() +
  geom_smooth(method = "lm") +
  theme_bw() +
    xlab("Temperature (C)") +
    ylab("Number of Spores") +
  theme(text = element_text(family = 'serif', face = 'bold', size = 18)) +
  theme(
    legend.position = c(.95, .95),
    legend.justification = c("right", "top"),
    legend.box.just = "right",
    legend.margin = margin(6, 6, 6, 6)
  )
