frozen_spore <- read_xlsx("data/CFU_counts.xlsx", sheet = 5) 
  
frozen_spore_clean <- frozen_spore |>
  rename("fresh" = "CFU/ml_2/22") |>
  rename("Frozen" = "CFU/ml...11")

# loads data of fresh versus frozen camples from plates 
ggplot(frozen_spore_clean, aes(Frozen, fresh, color = Species))+
  geom_line() +
  geom_smooth(method = "lm")+
  theme_bw() +
  xlab("Frozen CFU/ml") +
  ylab("Fresh CFU/ml") +
  theme(text = element_text(family = 'serif', face = 'bold', size = 18)) +
  theme(legend.position="none")
