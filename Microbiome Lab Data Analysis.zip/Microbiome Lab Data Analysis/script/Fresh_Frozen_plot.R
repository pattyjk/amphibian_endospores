##'--------------------------------
##' Lab Data Analysis
##' Fresh Vs Frozen Samples
##' 2023-03-27
##'
##'---------------------------------

library(stringr)
fresh_frozen <- read.table("data/fresh_frozen_TbCl.txt", sep = '\t', header = T) |>
  filter(Type1 == "Swab")

ggplot(fresh_frozen, aes(x = Froz_fluor, y = Fresh_fluor, color=Species)) +
  geom_point() +
  geom_smooth(method='lm') +
  theme_bw() +
  theme(text = element_text(family = 'serif', size = 18, face = 'bold')) +
  labs(color = "Method") +
  xlab("Frozen Fluorescense") +
  ylab("Fresh Fluorescense")

  

