##'--------------------------------
##' Lab Data Analysis
##' % Viable Spores TbCl
##' 2023-03-27
##'
##'---------------------------------

per_viable_spores <- read.delim("data/per_viable_spores.txt", sep = '\t', header=T)
per_viable_spores

ggplot(per_viable_spores, aes(Species, Per_viable, fill = Species))+
  geom_boxplot()+
  theme_bw()+
  coord_flip()+
  ylab("Percent viable spores (TbCl assay)")+
  theme(text = element_text(family = 'serif', face = 'bold', size = 18)) +
  theme(legend.position="none") +
  theme(axis.title.y = element_blank())

