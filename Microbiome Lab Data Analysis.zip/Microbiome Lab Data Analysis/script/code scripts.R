#`---------------------------------
#` Microbiome Lab Data analysis 
#' 
#' -------------------------------

# packages 
library(tidyr)
library(readr)
library(tidyverse)
library(ggplot2)

CFU_counts <- read.table("data/spore_cfu.txt", sep='\t', header=T)
View(CFU_counts)

# Creates a plot that shows both points and boxplots for both methods of sampling
ggplot(data = CFU_counts, aes(x=Species, y=CFU.ml, fill= Method)) +
  geom_boxplot() +
  geom_jitter() +
  facet_wrap(~Method) +
  xlab("Species") +
  ylab("CFU per mL") +
  theme_bw() +
  theme(plot.title = element_text(hjust = 0.5)) + 
  theme(text=element_text(family = "serif", face="bold", size=12)) +
  ggtitle("CFU per mL counts of differnet Amphibian Species") +
  coord_flip()
  
# Runs an anova test to determine statistical significance  
aov(CFU.ml~Method, data = CFU_counts)
#Terms:
#                      Method    Residuals
#Sum of Squares  6.061082e+12 1.056534e+14
#Deg. of Freedom            1           58

#Residual standard error: 1349670
#Estimated effects may be unbalanced

MCFU_aov <- aov(CFU.ml~Method, data = CFU_counts)

# runs a Tukey test to give us the limits of the data 
TukeyHSD(MCFU_aov)
# runs a t.test
# Method
#                   diff      lwr     upr     p adj
#Swab-Mucosome -635666.7 -1333232 61898.6 0.0732906

#aov for species and the methods
MUC_SWA_AOV <- aov(CFU.ml~Method+Species, data = CFU_counts)
TukeyHSD(MUC_SWA_AOV)

#another way of analysis, best if sample sizes are not the same
t.test()
pairwise.t.test(CFU.ml~Method)



  



